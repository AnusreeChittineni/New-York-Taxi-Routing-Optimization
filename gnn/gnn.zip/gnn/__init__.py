"""Graph neural network utilities and training pipelines."""
